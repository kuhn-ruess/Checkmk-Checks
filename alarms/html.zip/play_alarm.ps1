param (
  [string]$path = "Path"
)

if (-not (Test-Path $path)) {
    Write-Host "File not found at $path" -ForegroundColor Red
    exit 1
}

try {
	Add-Type -AssemblyName presentationCore
	$mediaplayer = New-Object System.Windows.Media.MediaPlayer
	$mediaplayer.Open($path)

	Start-Sleep 2
	$duration = $mediaplayer.NaturalDuration.TimeSpan.TotalSeconds
	$mediaplayer.Play()

	Start-Sleep $duration
	$mediaplayer.Stop()
	$mediaplayer.Close()
    Write-Host "Played $path" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "Unable to play $path" -ForegroundColor Red
	exit 1
}
<?php
function getUploadedFiles($directory) {
	$folder = opendir($directory);

	while ($file = readdir($folder)) {
		if($file !== "." && $file !== "..")
		{
			$filename = $directory."/".$file;
			$file_array[] = array(
				"filename" => $file,
				"path" => $filename
			);
		}
	}

	return $file_array;
}

$music = getUploadedFiles("alarms");

echo <<<HEAD
<!DOCTYPE html>
<html>
<body>
HEAD;

foreach($music as $value) {
	$title = $value["filename"];
	$path = $value["path"];

	echo <<<SOUND
<h1>$title</h1>
<audio controls>
  <source src="$path" type="audio/mpeg">
Your browser does not support the audio element.
</audio>
SOUND;
}

	echo <<<FOOTER
</body>
</html>
FOOTER;

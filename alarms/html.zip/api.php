<?php

if (isset($_GET["alarm"]) && !empty($_GET["alarm"])) {
	$title = $_GET["alarm"];
	$path = __DIR__."/alarms/".$_GET["alarm"];
	
	if (is_file($path)) {
		$output = null;
		$ret_code = null;
		$output = shell_exec("powershell.exe .\play_alarm.ps1 -path $path");
		
		if (preg_match("/^File not found at/", $output)) {
			header("Status: 400 ".$output);

		} elseif (preg_match("/^Played/", $output)) {
			header("Status: 200 ".$output);

		} elseif (preg_match("/^Unable to play/", $output)) {
			header("Status: 500 ".$output);
		}
	
	} else {
		header("Status: 500 Alarm not found");
	}

} else {
	header("Status: 400 Parameter is missing");
}